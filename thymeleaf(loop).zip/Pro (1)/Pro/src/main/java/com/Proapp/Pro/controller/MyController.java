package com.Proapp.Pro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;


    @Controller
    public class MyController {
        @GetMapping("/home/{user}")
        public String getData(@PathVariable int user, Model model){
//            List<Integer> list=List.of(1,2,3,4,5,6);
//            model.addAttribute("ListOfNumbers",list);

            List<Integer> table=new ArrayList<>();
            for(int i=1;i<=10;i++)
            {
                table.add(user*i);
            }
            model.addAttribute("number",user);
            model.addAttribute("table",table);
            return "home";
        }
}
