package com.thymeleaf.tutorial.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class usercontroller {
    @GetMapping("/show/{age}")
    public String show(@PathVariable int age, Model model)
    {
        int studAge=age;
        model.addAttribute("name",studAge);
        return "show";
    }
}
